import aiohttp

CBU_URL = "https://cbu.uz/oz/arkhiv-kursov-valyut/json/"
MAIN_CURRENCIES = ("USD", "EUR", "RUB", "GBP", "KZT", "CNY", "TRY")


async def fetch_rates() -> dict[str, dict]:
    """CBU API'dan kurslarni oladi: {'USD': {'rate': 12650.5, 'diff': 10.2, 'date': '...'}}"""
    timeout = aiohttp.ClientTimeout(total=10)
    async with aiohttp.ClientSession(timeout=timeout) as session:
        async with session.get(CBU_URL) as resp:
            resp.raise_for_status()
            data = await resp.json()

    return {
        item["Ccy"]: {
            "rate": float(item["Rate"]),
            "nominal": float(item.get("Nominal") or 1),
            "diff": float(item["Diff"]),
            "date": item["Date"],
        }
        for item in data
    }
