from aiogram import Router
from aiogram.filters import Command
from aiogram.types import Message

import database as db
from config import ADMIN_IDS

router = Router()


@router.message(Command("stats"))
async def stats(message: Message) -> None:
    if message.from_user.id not in ADMIN_IDS:
        return
    users = await db.count_users()
    reminders = await db.count_reminders()
    await message.answer(
        f"📊 <b>Statistika</b>\n\n👥 Foydalanuvchilar: {users}\n⏰ Faol eslatmalar: {reminders}"
    )
