from aiogram import Router
from aiogram.filters import Command, CommandStart
from aiogram.types import Message

router = Router()

HELP_TEXT = (
    "<b>Buyruqlar:</b>\n"
    "/kurs — asosiy valyuta kurslari (CBU)\n"
    "/convert 100 USD — valyutani so'mga aylantirish\n"
    "/remind 30m Dars qilish — eslatma (m=daqiqa, h=soat)\n"
    "/remind 18:30 Futbol — aniq vaqtga eslatma\n"
    "/myreminders — eslatmalarim\n"
    "/cancel 3 — eslatmani bekor qilish\n"
    "/help — yordam"
)


@router.message(CommandStart())
async def start(message: Message) -> None:
    name = message.from_user.first_name
    await message.answer(f"Salom, <b>{name}</b>! 👋\n\n{HELP_TEXT}")


@router.message(Command("help"))
async def help_cmd(message: Message) -> None:
    await message.answer(HELP_TEXT)
