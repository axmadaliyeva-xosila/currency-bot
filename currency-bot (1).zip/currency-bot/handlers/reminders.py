from aiogram import Router
from aiogram.filters import Command, CommandObject
from aiogram.types import Message

import database as db
from utils import fmt_dt, parse_time

router = Router()

USAGE = (
    "Foydalanish:\n"
    "<code>/remind 30m Dars qilish</code>\n"
    "<code>/remind 2h Dori ichish</code>\n"
    "<code>/remind 18:30 Futbol</code>"
)


@router.message(Command("remind"))
async def remind(message: Message, command: CommandObject) -> None:
    if not command.args:
        await message.answer(USAGE)
        return

    parts = command.args.split(maxsplit=1)
    if len(parts) < 2:
        await message.answer(USAGE)
        return

    when = parse_time(parts[0])
    if when is None:
        await message.answer("❌ Vaqt formati noto'g'ri.\n\n" + USAGE)
        return

    text = parts[1][:500]
    reminder_id = await db.add_reminder(message.from_user.id, text, int(when.timestamp()))
    await message.answer(
        f"✅ Eslatma #{reminder_id} qo'shildi.\n⏰ {fmt_dt(int(when.timestamp()))}\n📝 {text}"
    )


@router.message(Command("myreminders"))
async def my_reminders(message: Message) -> None:
    rows = await db.list_reminders(message.from_user.id)
    if not rows:
        await message.answer("Sizda faol eslatmalar yo'q.")
        return
    lines = [f"#{rid} — {fmt_dt(ts)}\n   {text}" for rid, text, ts in rows]
    await message.answer("📋 <b>Eslatmalaringiz:</b>\n\n" + "\n".join(lines))


@router.message(Command("cancel"))
async def cancel(message: Message, command: CommandObject) -> None:
    if not command.args or not command.args.strip().isdigit():
        await message.answer("Foydalanish: <code>/cancel 3</code>")
        return
    ok = await db.delete_reminder(message.from_user.id, int(command.args.strip()))
    await message.answer("🗑 Eslatma o'chirildi." if ok else "❌ Bunday eslatma topilmadi.")
