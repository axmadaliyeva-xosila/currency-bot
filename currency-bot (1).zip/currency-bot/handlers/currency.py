import logging

from aiogram import Router
from aiogram.filters import Command, CommandObject
from aiogram.types import Message

from services.cbu import MAIN_CURRENCIES, fetch_rates

router = Router()
log = logging.getLogger(__name__)


@router.message(Command("kurs"))
async def rates(message: Message) -> None:
    try:
        data = await fetch_rates()
    except Exception:
        log.exception("CBU API xatosi")
        await message.answer("⚠️ Kurslarni olib bo'lmadi, birozdan so'ng urinib ko'ring.")
        return

    lines = []
    date = ""
    for code in MAIN_CURRENCIES:
        if code not in data:
            continue
        item = data[code]
        date = item["date"]
        arrow = "🔺" if item["diff"] > 0 else "🔻" if item["diff"] < 0 else "➖"
        lines.append(
            f"<b>{item['nominal']:g} {code}</b> = {item['rate']:,.2f} so'm {arrow} {item['diff']:+.2f}"
        )
    await message.answer(f"💱 <b>Markaziy bank kurslari</b> ({date})\n\n" + "\n".join(lines))


@router.message(Command("convert"))
async def convert(message: Message, command: CommandObject) -> None:
    usage = "Foydalanish: <code>/convert 100 USD</code>"
    if not command.args:
        await message.answer(usage)
        return

    parts = command.args.split()
    if len(parts) != 2:
        await message.answer(usage)
        return

    try:
        amount = float(parts[0].replace(",", "."))
    except ValueError:
        await message.answer(usage)
        return
    code = parts[1].upper()

    try:
        data = await fetch_rates()
    except Exception:
        log.exception("CBU API xatosi")
        await message.answer("⚠️ Kurslarni olib bo'lmadi, birozdan so'ng urinib ko'ring.")
        return

    if code not in data:
        await message.answer(f"❌ '{code}' valyutasi topilmadi.")
        return

    item = data[code]
    result = amount * item["rate"] / item["nominal"]
    await message.answer(f"{amount:,.2f} {code} = <b>{result:,.2f} so'm</b>")
