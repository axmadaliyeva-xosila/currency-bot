import re
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo

from config import TIMEZONE

TZ = ZoneInfo(TIMEZONE)


def parse_time(value: str) -> datetime | None:
    """'30m', '2h' yoki '18:30' formatini datetime'ga aylantiradi."""
    value = value.strip().lower()
    now = datetime.now(TZ)

    m = re.fullmatch(r"(\d+)([mh])", value)
    if m:
        amount = int(m.group(1))
        if amount <= 0:
            return None
        delta = timedelta(minutes=amount) if m.group(2) == "m" else timedelta(hours=amount)
        return now + delta

    m = re.fullmatch(r"(\d{1,2}):(\d{2})", value)
    if m:
        hour, minute = int(m.group(1)), int(m.group(2))
        if hour > 23 or minute > 59:
            return None
        target = now.replace(hour=hour, minute=minute, second=0, microsecond=0)
        if target <= now:
            target += timedelta(days=1)
        return target

    return None


def fmt_dt(ts: int) -> str:
    return datetime.fromtimestamp(ts, TZ).strftime("%d.%m.%Y %H:%M")
