import asyncio
import logging
import time
from typing import Any, Awaitable, Callable

from aiogram import BaseMiddleware, Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.types import Message

import database as db
from config import BOT_TOKEN
from handlers import admin, common, currency, reminders

log = logging.getLogger(__name__)


class RegisterUserMiddleware(BaseMiddleware):
    """Har bir xabar yuborgan foydalanuvchini bazaga yozib boradi."""

    async def __call__(
        self,
        handler: Callable[[Message, dict[str, Any]], Awaitable[Any]],
        event: Message,
        data: dict[str, Any],
    ) -> Any:
        if event.from_user:
            await db.add_user(event.from_user.id, event.from_user.full_name)
        return await handler(event, data)


async def reminder_loop(bot: Bot) -> None:
    """Har 20 soniyada vaqti kelgan eslatmalarni yuboradi."""
    while True:
        try:
            for _, user_id, text in await db.pop_due_reminders(int(time.time())):
                try:
                    await bot.send_message(user_id, f"⏰ <b>Eslatma:</b>\n{text}")
                except Exception:
                    log.warning("Eslatmani yuborib bo'lmadi: user_id=%s", user_id)
        except Exception:
            log.exception("Eslatma tsiklida xato")
        await asyncio.sleep(20)


async def main() -> None:
    logging.basicConfig(level=logging.INFO)
    if not BOT_TOKEN:
        raise SystemExit("BOT_TOKEN topilmadi. .env faylini tekshiring.")

    await db.init_db()

    bot = Bot(BOT_TOKEN, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
    dp = Dispatcher()
    dp.message.outer_middleware(RegisterUserMiddleware())
    dp.include_routers(common.router, currency.router, reminders.router, admin.router)

    task = asyncio.create_task(reminder_loop(bot))
    try:
        await dp.start_polling(bot)
    finally:
        task.cancel()


if __name__ == "__main__":
    asyncio.run(main())
