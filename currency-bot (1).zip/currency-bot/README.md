# 💱 Valyuta va Eslatma Telegram boti

Python va **aiogram 3** asosida yozilgan Telegram bot.

## Imkoniyatlari

- 💱 **Valyuta kurslari**: O'zbekiston Markaziy banki (CBU) API orqali
- 🔄 **Konvertor**: istalgan valyutani so'mga aylantirish
- ⏰ **Eslatmalar**: `30m`, `2h` yoki `18:30` formatida, SQLite'da saqlanadi
- 📊 **Admin statistikasi**: foydalanuvchilar va eslatmalar soni

## Buyruqlar

| Buyruq | Tavsif |
|---|---|
| `/start`, `/help` | Yordam |
| `/kurs` | Asosiy valyuta kurslari |
| `/convert 100 USD` | Valyutani so'mga aylantirish |
| `/remind 30m Dars qilish` | Eslatma qo'yish |
| `/myreminders` | Eslatmalar ro'yxati |
| `/cancel 3` | Eslatmani bekor qilish |
| `/stats` | Statistika (faqat adminlar uchun) |

## Ishga tushirish

```bash
git clone https://github.com/<username>/currency-bot.git
cd currency-bot

python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate

pip install -r requirements.txt

cp .env.example .env            # Windows: copy .env.example .env
# .env faylida BOT_TOKEN va ADMIN_IDS ni to'ldiring

python main.py
```

Token olish uchun Telegram'da [@BotFather](https://t.me/BotFather) ga yozing.
O'z ID'ingizni [@userinfobot](https://t.me/userinfobot) orqali bilib olasiz.

## Loyiha tuzilmasi

```
currency-bot/
├── main.py            # kirish nuqtasi, eslatma tsikli
├── config.py          # sozlamalar (.env)
├── database.py        # SQLite bilan ishlash
├── utils.py           # vaqtni parse qilish
├── handlers/          # buyruq ishlovchilari
│   ├── common.py
│   ├── currency.py
│   ├── reminders.py
│   └── admin.py
└── services/
    └── cbu.py         # CBU API klienti
```

## Texnologiyalar

Python 3.10+, aiogram 3, aiohttp, aiosqlite

## Skrinshotlar

_Bu yerga botning skrinshotlarini qo'shing._

## Litsenziya

MIT
