import time

import aiosqlite

from config import DB_PATH


async def init_db() -> None:
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            """CREATE TABLE IF NOT EXISTS users (
                user_id INTEGER PRIMARY KEY,
                full_name TEXT,
                joined_at INTEGER
            )"""
        )
        await db.execute(
            """CREATE TABLE IF NOT EXISTS reminders (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                text TEXT NOT NULL,
                remind_at INTEGER NOT NULL
            )"""
        )
        await db.commit()


async def add_user(user_id: int, full_name: str) -> None:
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "INSERT OR IGNORE INTO users (user_id, full_name, joined_at) VALUES (?, ?, ?)",
            (user_id, full_name, int(time.time())),
        )
        await db.commit()


async def count_users() -> int:
    async with aiosqlite.connect(DB_PATH) as db:
        async with db.execute("SELECT COUNT(*) FROM users") as cur:
            return (await cur.fetchone())[0]


async def count_reminders() -> int:
    async with aiosqlite.connect(DB_PATH) as db:
        async with db.execute("SELECT COUNT(*) FROM reminders") as cur:
            return (await cur.fetchone())[0]


async def add_reminder(user_id: int, text: str, remind_at: int) -> int:
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute(
            "INSERT INTO reminders (user_id, text, remind_at) VALUES (?, ?, ?)",
            (user_id, text, remind_at),
        )
        await db.commit()
        return cur.lastrowid


async def list_reminders(user_id: int) -> list[tuple]:
    async with aiosqlite.connect(DB_PATH) as db:
        async with db.execute(
            "SELECT id, text, remind_at FROM reminders WHERE user_id = ? ORDER BY remind_at",
            (user_id,),
        ) as cur:
            return await cur.fetchall()


async def delete_reminder(user_id: int, reminder_id: int) -> bool:
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute(
            "DELETE FROM reminders WHERE id = ? AND user_id = ?", (reminder_id, user_id)
        )
        await db.commit()
        return cur.rowcount > 0


async def pop_due_reminders(now: int) -> list[tuple]:
    """Vaqti kelgan eslatmalarni qaytaradi va bazadan o'chiradi."""
    async with aiosqlite.connect(DB_PATH) as db:
        async with db.execute(
            "SELECT id, user_id, text FROM reminders WHERE remind_at <= ?", (now,)
        ) as cur:
            rows = await cur.fetchall()
        if rows:
            await db.executemany(
                "DELETE FROM reminders WHERE id = ?", [(r[0],) for r in rows]
            )
            await db.commit()
        return rows
